
public interface Validaton {
	double validaton();
	char SymbolValidation();

}
